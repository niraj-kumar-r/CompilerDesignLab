int main()
{
    int a = 10;
    // hello world
    float b = 20.0;
    int c = a + b;
    /*hello
    world, hello
    again*/
    int d = 30;
    if (d - c <= 0)
    {
        printf("hello world");
    }
}